package nl.inholland.jessevanevert625868endassingment.Models;

public enum MessageTypeEnum {INFO, ALERT, ERROR}
