package nl.inholland.jessevanevert625868endassingment.Models;

public class User extends Person{
    public User(int id, String username, String password) {
        super(id, username, password);
    }
}
