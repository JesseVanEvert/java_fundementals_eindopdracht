package nl.inholland.jessevanevert625868endassingment.Models;

public class Admin extends Person{
    public Admin(int id, String username, String password) {
        super(id, username, password);
    }
}
