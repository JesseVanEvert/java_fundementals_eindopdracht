package nl.inholland.jessevanevert625868endassingment.Views.Components;

public class UserMenuBar extends BaseMenuBar {
}
