package nl.inholland.jessevanevert625868endassingment.Views;

import javafx.stage.Stage;

public  class MainWindow {
    public static Stage mainWindow = new Stage();
}
