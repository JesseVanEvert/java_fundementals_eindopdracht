Logins:
User login -> username: user -> password: p@SSw0rd123
Admin login -> username: admin -> password: p@SSw0rd123
